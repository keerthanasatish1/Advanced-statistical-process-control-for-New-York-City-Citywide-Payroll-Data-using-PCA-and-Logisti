clear; close all;


X = xlsread('salary.xls');
X=X(:,1:end-1);

load salary.mat;
X = zscore(X); %standardize the data

[n,p]=size(X);
%scatterplot matrix of the data
[ha,ax,bigax,P]=plotmatrix(X);
axes(bigax);
delete(P); %delete the histograms
%Put the labels in.
for i=1:length(variables)
    txtax = axes('Position',get(ax(i,i),'Position'),'units','normalized');
    text(.55,.5,variables(i,:))
    set(txtax,'xtick',[],'ytick',[],'xgrid','off','ygrid','off','box','on')
end 

figure; 
boxplot(X,variables);

xbar = ones(n,1)'*X/n; 
H=eye(n)-ones(n,1)*ones(n,1)'/n; 
Y = H*X;
SS =Y'*Y/(n-1); 

figure('Name','Covariance Matrix');
plottable(SS,'%.2f');
set(gca,'LineWidth',1.2);
set(gca,'FontSize',12);
set(gca,'color',[.95 .95 .95],'XColor','white', 'YColor','white');
set(gcf,'color','white'); %camzoom(1.1); 
set(gcf,'InvertHardCopy','off'); 
set(gcf,'PaperPositionMode','auto');

variables={'Variance';'Skewness';'Kurtosis';'Entropy'};
displaytable(SS,variables)

X=zscore(X);



%Display covariance matrix



stdc = std(X);

[A,Z,lambda,Tsquare]=pca(X);



%Plotting Explained variance vs number of Principal Components (Q4d)
%using Plot and Pareto commands
expvar=100*lambda/sum(lambda);%percent of the total variability explained by each PC.

figure;
plot(expvar,'ko-','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
xlabel('Number of Principal Components','fontsize',14,'fontname','times');
ylabel('Explained Variance %','fontsize',14,'fontname','times');
%title('Scree Plot: Explained variance vs. Principal Component Number');

figure;
pareto(expvar);
xlabel('Number of Principal Components','fontsize',14,'fontname','times');
ylabel('Explained Variance %','fontsize',14,'fontname','times');
%title('Pareto of Explained variance vs. Principal Component Number');

%The first three principal components explain 87% of the variation. 
% This is an acceptably large percentage.

% PC2 score vs. PC1 score  (Q4f)
figure;
scatter(Z(:,1),Z(:,2),3,'o','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
%title('Scatter plot of 2nd PC vs. 1st PC');
xlabel('PC1 score','fontsize',14,'fontname','times'); 
ylabel('PC2 score','fontsize',14,'fontname','times');
%gname(observations); %press the Enter or Escape key to stop labeling.
% hold on;
% scattercloud(Z(:,1),Z(:,2));

figure;
scatter(Z(:,2),Z(:,3),3,'o','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
%title('Scatter plot of 2nd PC vs. 1st PC');
xlabel('PC2 score','fontsize',14,'fontname','times'); 
ylabel('PC3 score','fontsize',14,'fontname','times');
%gname(observations); %press the Enter or Escape key to stop labeling.
% hold on;
% scattercloud(Z(:,1),Z(:,2));


% %Plot Hotelling T-square and determine the most extreme value(Q4g)
% figure;
% plot3(X(:,1),X(:,2),X(:,3),'ro','MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',4);
% %set(gca,'YTickLabel',{''}); set(gca,'XTickLabel',{''}); grid;
% xlabel('$X_1$','fontsize',14,'fontname','times','Interpreter','LaTex'); 
% ylabel('$X_2$','fontsize',14,'fontname','times','Interpreter','LaTex');
% zlabel('$X_3$','fontsize',14,'fontname','times','Interpreter','LaTex');
% hold on; [h,s]=plotcov3(xbar',S,'num-pts',500,'plot-axes',0); grid;

figure;
[outliers, h] = tsquarechart(X);

%Plot PC1 control chart
figure;
k=1; %k-th PC score
[outliers, h] = pcachart(X,k);

%The following command show that two components account for 95.69% of the variance:
cumperc = 100*cumsum(lambda)/sum(lambda); %cumulative percentage

%Biplot helps visualize both the principal component coefficients for each variable and the principal 
%component scores for each observation in a single plot.
figure;
biplot(A(:,1:2),'Scores',Z(:,1:2),'VarLabels',{'X_1' 'X_2' 'X_3' 'X_4' 'X_5'})
%biplot(A(:,1:2),'Scores',Z(:,1:2),'VarLabels',variables)
xlabel('PC1','fontsize',14,'fontname','times'); 
ylabel('PC2','fontsize',14,'fontname','times');
axis tight;

%Interpretation of biplot:
% Each of the 3 variables is represented in this plot by a vector, and the direction and length of the 
% vector indicates how each variable contributes to the two principal components in the plot. For example, 
% the first principal component, represented in this biplot by the horizontal axis, 
% has positive coefficients for all 3 variables. That corresponds to the 3 vectors directed into 
% the right half of the plot. The second principal component, represented by the 
% vertical axis, has 2 positive coefficients for the variables X1 and X2, 
% and 1 negative coefficient for the variable X3. That corresponds to vectors 
% directed into  the top and bottom halves of the plot, respectively. This indicates that this component 
% distinguishes between observations that have high values for the first set of variables and low for the 
% second, and observations that have the opposite.
% Each of the n observations is represented in this plot by a point, and their locations indicate the 
% score of each observation for the two principal components in the plot. For example, points near the 
% left edge of this plot have the lowest scores for the first principal
% component. The angles of between the vectors representing the variables
% and the PCs indicate the contribution of the variable to the PCs.
% A narrow angle indicates that the variable plays a major role in the PC.
% For example, plant phosphorus is important in the first PC, while organic
% phosphorus is important in the second PC.

figure;
%biplot(A(:,1:3),'Scores',Z(:,1:3),'VarLabels',variables)
biplot(A(:,1:3),'Scores',Z(:,1:3),'VarLabels',{'X_1' 'X_2' 'X_3' 'X_4' 'X_5'})
xlabel('PC1','fontsize',14,'fontname','times'); 
ylabel('PC2','fontsize',14,'fontname','times');
zlabel('PC3','fontsize',14,'fontname','times');
axis tight;


%Component correlation matrix
[Ac,Zc,lambdac,Tsquarec]=pca(zscore(X));
C = Ac*sqrt(diag(lambdac));
figure('Name','Component Correlation Matrix');
plottable(C,'%.2f');
set(gca,'LineWidth',1.2);
set(gca,'FontSize',12);
set(gca,'color',[.95 .95 .95],'XColor','white', 'YColor','white');
set(gcf,'color','white'); %camzoom(1.1); 
set(gcf,'InvertHardCopy','off'); 
set(gcf,'PaperPositionMode','auto');

% figure;
% scatter(Zc(:,1),Zc(:,2),3,'o','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
% %title('Scatter plot of 2nd PC vs. 1st PC');
% xlabel('PC1 score','fontsize',14,'fontname','times'); 
% ylabel('PC2 score','fontsize',14,'fontname','times');
% 
% figure;
% scatter(Zc(:,2),Zc(:,3),3,'o','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
% %title('Scatter plot of 2nd PC vs. 1st PC');
% xlabel('PC2 score','fontsize',14,'fontname','times'); 
% ylabel('PC3 score','fontsize',14,'fontname','times');

% PC3 coef vs. PC2 coef  
figure;
scatter(A(:,2),A(:,3),3,'o','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
%title('Scatter plot of 2nd PC vs. 1st PC');
xlabel('PC2 coefficient','fontsize',14,'fontname','times'); 
ylabel('PC3 coefficient','fontsize',14,'fontname','times');
gname(variables); %press the Enter or Escape key to stop labeling.
% hold on;
% scattercloud(A(:,1),A(:,2));

figure;
scatter(A(:,1),A(:,2),3,'o','MarkerFaceColor',[.49 1 .63],'LineWidth',1);
%title('Scatter plot of 2nd PC vs. 1st PC');
xlabel('PC1 coefficient','fontsize',14,'fontname','times'); 
ylabel('PC2 coefficient','fontsize',14,'fontname','times');
gname(variables); %press the Enter or Escape key to stop labeling.

% %PCA residuals
% d=2;
% residuals = pcares(X,2);% returns the residuals obtained by retaining d principal components 

figure;
alpha = 0.05;
[outliers, h] = tsquarechart(X,alpha); %T^2 chart

figure;
k=1;
[outliers, h] = pcachart(X,k); %1st PCA control chart
ylabel('$Z_1$','fontsize',14,'fontname','times','Interpreter','LaTex'); 

