%=====================================================================
% Logistic Regression Analysis for Mining-BCTCoin(BCT)-Data.
% By Shalini (40041284)
%=====================================================================
% Dataset:
% https:https://github.com/plotly/datasets/blob/master/Mining-BTC-180.csv#L1
% Dataset Name : Mining-BTC-180.csv
%=====================================================================%% Logistic Regression

%% Initialization
clear ; close all; clc

%% Load Data
data = load('salary.mat');
X = data(:, [1, 2:end]); 
y = data(:, 1);  


%  It's always a good idea to first plot the problem to solve
fprintf(['Plotting data with + indicating (y = 1) examples and o ' ...
         'indicating (y = 0) examples.\n']);
plotData(X, y);

% Put some labels 
hold on;
% Labels and Legend
%title('Prediction of Level of Mining Revenue Based on Previous Observations')
xlabel('Salary')
ylabel('Mid')

% Specified in plot order
legend('Above Average', 'Below Average')
hold on;

%fprintf('\nProgram paused. Press enter to continue.\n');
%pause;


%% ============ Compute Cost and Gradient ============
%  implement the cost and gradient for logistic regression

%  Setup the data matrix appropriately, and add ones for the intercept term
[m, n] = size(X);

% Add intercept term to x and X_test
X = [ones(m, 1) X];

% Initialize fitting parameters
initial_theta = zeros(n + 1, 1);

% Compute and display initial cost and gradient
[cost, gradient] = costFunction(initial_theta, X, y);

fprintf('Cost at initial theta (zeros): %f\n', cost);
fprintf('Gradient at initial theta (zeros): \n');
fprintf(' %f \n', gradient);
 
%fprintf('\nProgram paused. Press enter to continue.\n');
%pause;


%% ============= Optimizing using fminunc  =============
%  use a built-in function (fminunc) to find the
%  optimal parameters theta. Octave's fminunc is an optimization
%  solver that finds the minimum of an unconstrained function. 
%  For logistic regression, you want to optimize the cost
%  function J(theta) with parameters theta.

%  Set options for fminunc
options = optimset('GradObj', 'on', 'MaxIter', 400);

%  Run fminunc to obtain the optimal theta
%  This function will return theta and the cost 
[theta, cost] = fminunc(@(t)(costFunction(t, X, y)), initial_theta, options);
% NOTE: that by using fminunc, you do not have to write any loops yourself,
% or set a learning rate like you did for gradient descent. You ONLY need
% to provide a function calculating the cost and the gradient.

% Print theta to screen
fprintf('Cost at theta found by fminunc: %f\n', cost);
fprintf('theta: \n');
fprintf(' %f \n', theta);

% Plot Boundary
plotDecisionBoundary(theta, X, y);

% Put some labels 
hold on;
% Labels and Legend
xlabel('Hash Rate')
ylabel('Cost-per-trans-USD')

% Specified in plot order
legend('Above Average', 'Below Average')
hold on;

%fprintf('\nProgram paused. Press enter to continue.\n');
%pause;

%% ============== Part 4: Predict and Accuracies ==============

prob = sigmoid([1 4882255 22] * theta);
fprintf(['Pridicted probability is %f\n\n'], prob);

% Compute accuracy on our training set
p = predict(theta, X);

fprintf('Train Accuracy: %f\n', mean(double(p == y)) * 100);



