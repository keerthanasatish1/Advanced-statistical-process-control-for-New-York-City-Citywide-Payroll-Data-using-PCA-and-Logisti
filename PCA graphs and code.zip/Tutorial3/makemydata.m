clear; 
[X, text, alldata] = xlsread('salary.xls');
variables = char(text(1,2:end));
observations = char(text(2:end,1));
save salary.mat X variables observations