clc
clear

Data = xlsread('salary.xls');
Y= Data(:,end);
X= Data(:,1:end-1);
X=zscore(X);

[A,Z,lambda,Tsquare]=pca(X);

Ytrain=Y(1:ceil(0.8*size(Data,1)));
Ztrain=Z(1:ceil(0.8*size(Data,1)),:);

Ytest=Y(ceil(0.8*size(Data,1))+1:end);
Ztest=Z(ceil(0.8*size(X,1))+1:end,:);


figure;
histogram(Z(:,1));
title('{\bf Histogram of first component}');
figure;
histogram(Z(:,2));
title('{\bf Histogram of second component}');
figure;
histogram(Ytrain);
title('{\bf Histogram of labels}');

% using all features
tic
B1 = mnrfit(Ztrain,Ytrain);
pihat1 = mnrval(B1,Ztest) ;
t1=toc
sum1=0;

for i=1:size(Ztest,1)
    
    y=find(pihat1(i,:)==max(pihat1(i,:)));
    if y== Ytest(i)
        sum1=sum1+1;
    end
end

acc1 = sum1/size(Ztest,1)

pred = mnrval(B1,Ztest) ;

[~,pred1] = max(pred,[],2);

[c,cm1,ind,per] = confusion(Ytest'-1, pred1'-1)


% using first 2 features
tic
B2 = mnrfit(Ztrain(:,1:2),Ytrain);
pihat2 = mnrval(B2,Ztest(:,1:2)) ;
t2=toc
sum2=0;

for i=1:size(Ztest,1)
    
    y=find(pihat2(i,:)==max(pihat2(i,:)));
    if y== Ytest(i)
        sum2=sum2+1;
    end
end



acc2 = sum2/size(Ztest,1)

d = 0.02;
[x1Grid,x2Grid] = meshgrid(min(Ztest(:,1)):d:max(Ztest(:,1)),...
    min(Ztest(:,2)):d:max(Ztest(:,2)));
xGrid = [x1Grid(:),x2Grid(:)];
N = size(xGrid,1);

score = mnrval(B2,xGrid) ;

[~,maxScore] = max(score,[],2);



figure
 h(1:2)=gscatter(xGrid(:,1),xGrid(:,2),maxScore, [0.5 0.1 0.5; 0.5 0.5 0.1]);
hold on
 h(3:4)=gscatter(Ztest(:,1),Ztest(:,2),Ytest);
title('{\bf banknote authentication using logistic regression}');
xlabel('PC1');
ylabel('PC2');
legend(h,{'genuine','fake',...
'observed genuine','observed fake'},...
  'Location','Northwest');
 axis tight
 hold off
 
 figure;
 c = categorical({'All the features','First two component'});
 bar(c,[acc1 t1 ; acc2 t2]);
 legend('Accuracy', 'Time');
 title('Bar Chart of accuracy and calculation time')
 
pred = mnrval(B2,Ztest(:,1:2)) ;

[~,pred2] = max(pred,[],2);

[c,cm2,ind,per] = confusion(Ytest'-1, pred2'-1)

[X1,Y1] = perfcurve(Ytest'-1,pred1'-1,'1');
[X2,Y2] = perfcurve(Ytest'-1,pred2'-1,'1');

figure;

plot(X1,Y1)
hold on
plot(X2,Y2)
legend('Using all the features','Using the first two components')
xlabel('False positive rate'); ylabel('True positive rate');
title('ROC Curves')
hold off


